a) ABC**
b) 0A-B+C-D+
c) A0B-**C+
d) AB+D*EFAD*+/+C+
e) AB&&C||EF>!||
f) ABC<CD>||!&&!C<E||